<?php
$apiKey = 'AIzaSyB63ypD5Rl9wCYN2Ug8OmvK5nT9KLXD0bs'; // Sizning API kalitingiz

$text = $_POST['text'] ?? '';

$data = [
  'input' => ['text' => $text],
  'voice' => [
    'languageCode' => 'uz-UZ',
    'name' => 'uz-UZ-Standard-A'
  ],
  'audioConfig' => ['audioEncoding' => 'MP3']
];

$options = [
  'http' => [
    'method'  => 'POST',
    'header'  => "Content-Type: application/json\r\n",
    'content' => json_encode($data)
  ]
];

$context  = stream_context_create($options);

// Bu yerda API key query stringda yuboriladi
$url = 'https://texttospeech.googleapis.com/v1/text:synthesize?key=' . $apiKey;

$response = file_get_contents($url, false, $context);
$result = json_decode($response, true);

// Xatolikni tekshirish
if (isset($result['error'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $result['error']['message']]);
    exit;
}

// Ovoz chiqarish
$audio = base64_decode($result['audioContent']);
header('Content-Type: audio/mpeg');
echo $audio;
?>